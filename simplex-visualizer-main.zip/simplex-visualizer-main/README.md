# 🚀 Simplex Method Visualizer

A Flask web application that solves linear programming problems using the Simplex method. It provides step-by-step matrix transformations and visualizes 2D & 3D inequalities where applicable. 📊📈

## ✨ Features
- Step-by-step solution for the **Simplex Method** 🧮
- **Matrix representation** for each iteration 🔢
- **Graphical visualization** for 2-variable problems 📉
- **3D plotting** for 3-variable problems (if feasible) 🔺
- Supports higher dimensions by returning matrices and solutions only 📄
- **User-friendly input** with separate labeled boxes ✅

## 🛠 Installation
1. **Clone the repository:**  
   ```bash
   git clone https://github.com/rajm012/simplex-visualizer.git
   cd simplex-solver
   ```
2. **Create a virtual environment & activate it:**  
   ```bash
   python -m venv venv
   source venv/bin/activate   # On Windows use: venv\Scripts\activate
   ```
3. **Install dependencies:**  
   ```bash
   pip install -r requirements.txt
   ```
4. **Run the Flask app:**  
   ```bash
   flask run
   ```
   The app will be available at **http://127.0.0.1:5000/** 🚀

## 🔢 Input Format
- Objective function: Maximize/Minimize a linear function (e.g., `3x + 5y`)
- Constraints: Linear inequalities with coefficients (e.g., `2x + 3y ≤ 10`)
- Separate labeled input fields for coefficients ✍️

## 📊 Output
- Step-by-step **Simplex tableau transformation** 🔄
- Final **optimal solution** ✅
- **Graphical representation** (for 2D & 3D cases) 📈

## 🌟 Future Enhancements
- Support for **dual simplex method** 🔄
- **Sensitivity analysis** for changes in constraints 🎯
- **More advanced visualizations** 📊

## 📌 Contributions
Feel free to **fork** the repository, create issues, or submit **pull requests**! Contributions are welcome! 🎉

## 📜 License
 **No License** 📄

