# app.py
from flask import Flask, render_template, request
import numpy as np
import matplotlib
matplotlib.use('Agg')  # Add before importing pyplot
import matplotlib.pyplot as plt
import io
import base64

app = Flask(__name__)

def simplex_method(c, A, b):
    num_vars = len(c)
    num_constraints = len(A)

    # Store all tableau states
    all_tableaux = []

    # Construct the initial simplex tableau
    tableau = np.zeros((num_constraints + 1, num_vars + num_constraints + 1))
    
    # Fill in the objective function row
    tableau[0, :num_vars] = -np.array(c)
    
    # Fill in the constraint rows
    for i in range(num_constraints):
        tableau[i + 1, :num_vars] = A[i]
        tableau[i + 1, num_vars + i] = 1  # Slack variables
        tableau[i + 1, -1] = b[i]
    
    # Store initial tableau
    all_tableaux.append(tableau.tolist())
    
    # Simplex Iteration
    iteration = 1
    while np.any(tableau[0, :-1] < 0):
        # Pivot Column (Most negative coefficient in objective row)
        pivot_col = np.argmin(tableau[0, :-1])

        # Find Pivot Row using Minimum Ratio Test
        ratios = []
        for i in range(1, num_constraints + 1):
            if tableau[i, pivot_col] > 0:
                ratios.append(tableau[i, -1] / tableau[i, pivot_col])
            else:
                ratios.append(np.inf)

        if all(r == np.inf for r in ratios):
            return "Unbounded Solution", None, all_tableaux  # No valid pivot row

        pivot_row = np.argmin(ratios) + 1  # Adjust index

        # Normalize Pivot Row
        tableau[pivot_row] /= tableau[pivot_row, pivot_col]

        # Perform Row Operations
        for i in range(num_constraints + 1):
            if i != pivot_row:
                tableau[i] -= tableau[i, pivot_col] * tableau[pivot_row]
        
        # Store current tableau after each iteration
        all_tableaux.append(tableau.tolist())
        iteration += 1

    # Extract Solution
    solution = np.zeros(num_vars)
    for i in range(num_vars):
        col = tableau[:, i]
        if np.sum(col == 1) == 1 and np.sum(col) == 1:
            solution[i] = tableau[np.where(col == 1)[0], -1][0]

    return tableau.tolist(), solution.tolist(), all_tableaux

def plot_2d_inequalities(A, b):
    plt.figure(figsize=(10, 6))
    x = np.linspace(-10, 10, 400)

    for i in range(len(A)):
        a, c = A[i]
        y = (b[i] - a * x) / c
        plt.plot(x, y, label=f'Constraint {i+1}')
        plt.fill_between(x, y, -100, alpha=0.3)

    plt.axhline(0, color='black', lw=1)
    plt.axvline(0, color='black', lw=1)
    plt.xlabel("X")
    plt.ylabel("Y")
    plt.title("Constraint Visualization")
    plt.legend()
    plt.grid(True)

    img = io.BytesIO()
    plt.savefig(img, format='png', bbox_inches='tight')
    img.seek(0)
    plt.close()
    return base64.b64encode(img.getvalue()).decode()

def plot_3d_inequalities(A, b):
    fig = plt.figure(figsize=(10, 8))
    ax = fig.add_subplot(111, projection='3d')

    x = np.linspace(-10, 10, 30)
    y = np.linspace(-10, 10, 30)
    X, Y = np.meshgrid(x, y)

    for i in range(len(A)):
        a, b1, c = A[i]
        Z = (b[i] - a * X - b1 * Y) / c
        ax.plot_surface(X, Y, Z, alpha=0.5)

    ax.set_xlabel("X")
    ax.set_ylabel("Y")
    ax.set_zlabel("Z")
    ax.set_title("3D Constraint Visualization")

    img = io.BytesIO()
    plt.savefig(img, format='png', bbox_inches='tight')
    img.seek(0)
    plt.close()
    return base64.b64encode(img.getvalue()).decode()

@app.route("/", methods=["GET", "POST"])
def index():
    result = None
    plot_url = None
    plot_url_3d = None
    tableau = None
    all_tableaux = None

    if request.method == "POST":
        num_vars = int(request.form["num_vars"])
        num_constraints = int(request.form["num_constraints"])

        # Get Objective Function
        obj_func = [float(request.form[f"obj_{i}"]) for i in range(num_vars)]

        # Get Constraints
        lhs_ineq = []
        rhs_ineq = []

        for i in range(num_constraints):
            lhs_ineq.append([float(request.form[f"lhs_{i}_{j}"]) for j in range(num_vars)])
            rhs_ineq.append(float(request.form[f"rhs_{i}"]))

         # Solve the problem using Simplex
        tableau, result, all_tableaux = simplex_method(obj_func, lhs_ineq, rhs_ineq)

        # Generate 2D or 3D plot
        if num_vars == 2:
            plot_url = plot_2d_inequalities(lhs_ineq, rhs_ineq)
        elif num_vars == 3:
            plot_url_3d = plot_3d_inequalities(lhs_ineq, rhs_ineq)

    return render_template("index.html", result=result, tableau=tableau, 
                           all_tableaux=all_tableaux, 
                           plot_url=plot_url, plot_url_3d=plot_url_3d)


if __name__ == "__main__":
    app.run(debug=True)

    